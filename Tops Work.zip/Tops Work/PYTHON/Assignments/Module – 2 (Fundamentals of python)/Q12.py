# Write a Python program to calculate the length of a string

def legn(s):
    return len(s)  

inp = input("Enter a string: ")

length = legn(inp)
print("The length of the string is:", length)

