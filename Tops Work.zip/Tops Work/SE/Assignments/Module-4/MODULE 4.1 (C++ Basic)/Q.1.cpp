// WAP to print “Hello World” using C++
// Ans..

#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World: ";
    return 0;
}